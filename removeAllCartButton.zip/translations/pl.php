<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{removeallcartbutton}prestashop>removeallcartbutton_9f1472ac1a57dcc593f4cef85b223bde'] = 'Usuń wszystkie produkty z koszyka';
$_MODULE['<{removeallcartbutton}prestashop>removeallcartbutton_4e45a0cb2e9429323f3b8fc52491a7a9'] = 'Moduł pozwalający użytkownikowi usunąć wszystkie produktuy z koszyka';
